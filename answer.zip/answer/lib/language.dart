class Language {
  int id;
  String name;
  String flag;
  String langaugeCode;
  Language(this.id, this.name, this.flag, this.langaugeCode);

  static List<Language> langaugeList() {
    return <Language>[
      Language(1, "🇮🇳", "इंडिया", "hi"),
      Language(2, "🇦🇪", "الإمارات العربية المتحدة", "ar"),
      Language(3, '🇸🇪', 'svenska', 'sv'),
      Language(4, "🇨🇭", "Schweiz", "de"),
      Language(5, "🇧🇶", "Nederland", "nl"),
      Language(6, "🇩🇪", "Deutschland", "de"),
      Language(7, "🇧🇪", "Belgique", "fr"),
      Language(8, "🇪🇸", "Español", "es"),
      Language(9, "🇦🇿", "azerbaycan", "az"),
      Language(10, "🇮🇹", "Italiano", "it"),
      Language(11, "🇫🇷", "français", "fr"),
      Language(12, "🇸🇦", "عربى", "ar"),
      Language(13, "🇹🇼", "臺灣", "zh-cn"),
      Language(14, "🇻🇳", "Việt Nam", "vi"),
      Language(15, "🇹🇭", "ประเทศไทย", "th"),
      Language(16, "🇨🇳", "中国", "zh-cn"),
      Language(17, "🇯🇵", "日本", "ja"),

    ];
  }
}
